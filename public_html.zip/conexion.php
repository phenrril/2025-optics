<?php
    $host = "127.0.0.1:3306";
    $user = "u375391241_opticaojito";
    //$clave = "mmY5kpMU6XZeuBx";
     $clave = "Optica2024";
    $bd = "u375391241_sis_ventas";
    $conexion = mysqli_connect($host,$user,$clave,$bd);
    if (mysqli_connect_errno()){
        echo "No se pudo conectar a la base de datos";
        exit();
    }
    mysqli_select_db($conexion,$bd) or die("No se encuentra la base de datos");
    mysqli_set_charset($conexion,"utf8");
?>
